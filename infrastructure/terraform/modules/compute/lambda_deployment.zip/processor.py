"""
OSINT Data Processor Lambda Function
Phase 8A Enhanced: Integrated with advanced search engine capabilities

This module processes collected threat intelligence data with focus on:
- STIX 2.1 compliance validation and enrichment
- Batch processing for cost optimization
- Data quality scoring and filtering
- Cross-source correlation and deduplication
- Advanced multi-criteria search with fuzzy matching
- Complex correlation analytics and result ranking
- Multi-format export capabilities (JSON, CSV, STIX)

Features:
- Higher memory allocation (512MB) for intensive processing
- Batch processing up to 100 indicators per invocation
- STIX 2.1 validation and normalization
- Confidence scoring and quality assessment
- Advanced search engine with pattern recognition
- Export engine with compression and optimization
"""

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Import advanced search engine capabilities
try:
    from search_engine import (
        AdvancedSearchEngine, SearchQuery, SearchType, SortOrder,
        search_engine as global_search_engine
    )
    from export_engine import (
        ThreatIntelExportEngine, ExportRequest, ExportFormat, CompressionType,
        export_engine as global_export_engine
    )
    ADVANCED_SEARCH_AVAILABLE = True
except ImportError:
    logger.warning("Advanced search engine not available - using basic search")
    ADVANCED_SEARCH_AVAILABLE = False

# Import event utilities for Phase 8B integration
try:
    from event_utils import (
        emit_processing_completed, emit_critical_threat, WorkflowTracker, ThreatAnalyzer,
        ProcessingPriority, EventEmitter, EventType, EventValidator
    )
    EVENT_INTEGRATION_AVAILABLE = True
except ImportError:
    logger.warning("Event utilities not available - running without event integration")
    EVENT_INTEGRATION_AVAILABLE = False

import json
import boto3
import logging
import os
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional, Tuple
from decimal import Decimal
import re
import hashlib
from botocore.exceptions import ClientError



# AWS Service Clients
dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')
secrets_client = boto3.client('secretsmanager')

# Environment Variables
ENVIRONMENT = os.environ.get('ENVIRONMENT', 'dev')
SECRETS_MANAGER_ARN = os.environ['SECRETS_MANAGER_ARN']
THREAT_INTEL_TABLE = os.environ['THREAT_INTEL_TABLE']
DEDUP_TABLE = os.environ['DEDUP_TABLE']
RAW_DATA_BUCKET = os.environ['RAW_DATA_BUCKET']
PROCESSED_DATA_BUCKET = os.environ['PROCESSED_DATA_BUCKET']
STIX_VERSION = os.environ.get('STIX_VERSION', '2.1')
MAX_BATCH_SIZE = int(os.environ.get('MAX_BATCH_SIZE', '100'))

# DynamoDB Tables
threat_intel_table = dynamodb.Table(THREAT_INTEL_TABLE)
dedup_table = dynamodb.Table(DEDUP_TABLE)

# STIX 2.1 Pattern Validation Regexes
STIX_PATTERNS = {
    'ipv4': r'\[ipv4-addr:value\s*=\s*\'([0-9]{1,3}\.){3}[0-9]{1,3}\'\]',
    'ipv6': r'\[ipv6-addr:value\s*=\s*\'[0-9a-fA-F:]+\'\]',
    'domain': r'\[domain-name:value\s*=\s*\'[a-zA-Z0-9.-]+\'\]',
    'url': r'\[url:value\s*=\s*\'https?://[^\s]+\'\]',
    'file_hash': r'\[file:hashes\.(MD5|SHA-1|SHA-256)\s*=\s*\'[a-fA-F0-9]+\'\]'
}


def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Main Lambda handler for threat intelligence data processing

    Args:
        event: Lambda event data (API Gateway, SQS, or manual trigger)
        context: Lambda runtime context

    Returns:
        Dict containing processing results and metrics
    """
    try:
        logger.info(f"Starting threat intelligence processing - Environment: {ENVIRONMENT}")

        # Initialize processing results
        results = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'environment': ENVIRONMENT,
            'processing_stats': {
                'indicators_processed': 0,
                'valid_indicators': 0,
                'invalid_indicators': 0,
                'enriched_indicators': 0,
                'correlation_matches': 0
            },
            'quality_metrics': {
                'avg_confidence_score': 0,
                'high_confidence_count': 0,
                'low_confidence_count': 0
            },
            'errors': []
        }

        # Phase 8B: Handle EventBridge events
        correlation_id = None
        workflow_id = None
        processing_priority = ProcessingPriority.STANDARD

        if EVENT_INTEGRATION_AVAILABLE:
            # Extract correlation and workflow IDs from event
            correlation_id = WorkflowTracker.extract_correlation_id(event)
            workflow_id = event.get('workflow_id') or (event.get('detail', {}).get('workflow_id'))

            # Handle EventBridge collection completed events
            if 'source' in event and 'detail' in event:
                if event.get('source', '').startswith('threat-intel.'):
                    logger.info(f"Processing EventBridge event from {event.get('source')}")
                    return handle_eventbridge_processing(event, correlation_id, workflow_id)

        # Enhanced processing modes including search, export, and priority processing
        if 'action' in event:
            action = event.get('action')

            if action == 'search' and ADVANCED_SEARCH_AVAILABLE:
                return handle_advanced_search(event)
            elif action == 'export' and ADVANCED_SEARCH_AVAILABLE:
                return handle_export_request(event)
            elif action == 'process':
                # Extract priority and workflow info for action-based processing
                if EVENT_INTEGRATION_AVAILABLE:
                    priority_str = event.get('priority', 'standard')
                    processing_priority = ProcessingPriority(priority_str)
                    workflow_id = event.get('workflow_id')
                    correlation_id = event.get('correlation_id')
                # Continue with standard processing
                pass
            else:
                return create_response(400, {'error': f'Unsupported action: {action}'})

        # Determine processing mode based on event source
        if 'source' in event and event['source'] == 'aws:sqs':
            # Process SQS batch messages
            indicators = extract_indicators_from_sqs(event)
        elif 'Records' in event:
            # Process S3 event notifications
            indicators = extract_indicators_from_s3_events(event)
        else:
            # Manual processing mode - scan for unprocessed indicators
            indicators = scan_unprocessed_indicators(MAX_BATCH_SIZE)

        if not indicators:
            logger.info("No indicators found for processing")
            return create_response(200, results)

        logger.info(f"Processing {len(indicators)} indicators")

        # Process indicators in batches
        for batch in batch_indicators(indicators, MAX_BATCH_SIZE):
            batch_results = process_indicator_batch(batch)
            update_processing_stats(results['processing_stats'], batch_results)

        # Calculate quality metrics
        calculate_quality_metrics(results)

        # Store processing results
        store_processing_results(results)

        logger.info(f"Processing completed: {results['processing_stats']['valid_indicators']} "
                   f"valid indicators processed")

        # Phase 8B: Emit processing completed events and detect critical threats
        if EVENT_INTEGRATION_AVAILABLE:
            # Identify high-confidence indicators for enrichment
            high_confidence_indicators = _extract_high_confidence_indicators(indicators, results)

            # Detect critical threats for immediate alerting
            critical_threats = _detect_critical_threats(indicators, results)

            # Emit processing completed event
            processing_success = emit_processing_completed(
                stats={
                    'indicators_processed': results['processing_stats']['indicators_processed'],
                    'valid_indicators': results['processing_stats']['valid_indicators'],
                    'invalid_indicators': results['processing_stats']['invalid_indicators'],
                    'enriched_indicators': results['processing_stats']['enriched_indicators'],
                    'high_confidence_indicators': high_confidence_indicators
                },
                workflow_id=workflow_id,
                correlation_id=correlation_id
            )

            if processing_success:
                logger.info(f"Processing completed event emitted - workflow_id: {workflow_id}")
                results['workflow'] = {
                    'correlation_id': correlation_id,
                    'workflow_id': workflow_id,
                    'processing_event_emitted': True,
                    'high_confidence_count': len(high_confidence_indicators),
                    'critical_threats_count': len(critical_threats)
                }
            else:
                logger.warning("Failed to emit processing completed event")

            # Emit critical threat events if detected
            if critical_threats:
                critical_success = emit_critical_threat(
                    indicators=critical_threats,
                    correlation_id=correlation_id
                )
                logger.critical(f"Critical threats detected and {'alerted' if critical_success else 'alert failed'}: {len(critical_threats)} threats")

        return create_response(200, results)

    except Exception as e:
        error_msg = f"Error in threat intelligence processing: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return create_response(500, {
            'error': 'Internal server error',
            'message': str(e) if ENVIRONMENT == 'dev' else 'Processing failed'
        })


def extract_indicators_from_sqs(event: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract indicators from SQS batch messages

    Args:
        event: SQS batch event

    Returns:
        List of indicator objects
    """
    indicators = []

    try:
        for record in event.get('Records', []):
            body = json.loads(record.get('body', '{}'))
            if 'indicator' in body:
                indicators.append(body['indicator'])

    except Exception as e:
        logger.error(f"Error extracting indicators from SQS: {e}")

    return indicators


def extract_indicators_from_s3_events(event: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract indicators from S3 event notifications

    Args:
        event: S3 event notification

    Returns:
        List of indicator objects
    """
    indicators = []

    try:
        for record in event.get('Records', []):
            if record.get('eventSource') == 'aws:s3':
                bucket = record['s3']['bucket']['name']
                key = record['s3']['object']['key']

                # Download and parse S3 object
                response = s3_client.get_object(Bucket=bucket, Key=key)
                data = json.loads(response['Body'].read())

                if isinstance(data, list):
                    indicators.extend(data)
                elif isinstance(data, dict) and 'indicators' in data:
                    indicators.extend(data['indicators'])

    except Exception as e:
        logger.error(f"Error extracting indicators from S3: {e}")

    return indicators


def scan_unprocessed_indicators(limit: int) -> List[Dict[str, Any]]:
    """
    Scan DynamoDB for unprocessed indicators

    Args:
        limit: Maximum number of indicators to retrieve

    Returns:
        List of unprocessed indicator objects
    """
    indicators = []

    try:
        # Scan for indicators without processed_at timestamp
        response = threat_intel_table.scan(
            FilterExpression='attribute_not_exists(processed_at)',
            Limit=limit
        )

        indicators = response.get('Items', [])
        logger.info(f"Found {len(indicators)} unprocessed indicators")

    except Exception as e:
        logger.error(f"Error scanning for unprocessed indicators: {e}")

    return indicators


def process_indicator_batch(indicators: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Process a batch of indicators for STIX compliance and quality

    Args:
        indicators: List of indicator objects to process

    Returns:
        Dict containing batch processing results
    """
    batch_results = {
        'processed': 0,
        'valid': 0,
        'invalid': 0,
        'enriched': 0,
        'correlations': 0,
        'confidence_scores': []
    }

    for indicator in indicators:
        try:
            # Validate STIX 2.1 compliance
            is_valid, validation_errors = validate_stix_compliance(indicator)

            if is_valid:
                # Enrich indicator with additional metadata
                enriched_indicator = enrich_indicator(indicator)

                # Check for correlations with existing data
                correlations = find_correlations(enriched_indicator)

                # Update confidence score based on correlations
                updated_confidence = update_confidence_score(
                    enriched_indicator, correlations)

                # Store processed indicator
                store_processed_indicator(enriched_indicator, correlations)

                batch_results['valid'] += 1
                batch_results['enriched'] += 1
                batch_results['correlations'] += len(correlations)
                batch_results['confidence_scores'].append(updated_confidence)

            else:
                logger.warning(f"Invalid indicator: {validation_errors}")
                batch_results['invalid'] += 1

            batch_results['processed'] += 1

        except Exception as e:
            logger.error(f"Error processing indicator: {e}")
            batch_results['invalid'] += 1

    return batch_results


def validate_stix_compliance(indicator: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """
    Validate indicator against STIX 2.1 specification

    Args:
        indicator: Indicator object to validate

    Returns:
        Tuple of (is_valid, list_of_errors)
    """
    errors = []

    # Required fields validation
    required_fields = ['type', 'spec_version', 'id', 'created', 'modified', 'pattern', 'labels']
    for field in required_fields:
        if field not in indicator:
            errors.append(f"Missing required field: {field}")

    # STIX version validation
    if indicator.get('spec_version') != '2.1':
        errors.append(f"Invalid spec_version: {indicator.get('spec_version')}")

    # Pattern syntax validation
    pattern = indicator.get('pattern', '')
    if pattern and not validate_stix_pattern(pattern):
        errors.append(f"Invalid STIX pattern syntax: {pattern}")

    # Confidence score validation
    confidence = indicator.get('confidence')
    if confidence is not None and (not isinstance(confidence, (int, float)) or
                                  confidence < 0 or confidence > 100):
        errors.append(f"Invalid confidence score: {confidence}")

    # Labels validation
    labels = indicator.get('labels', [])
    if not isinstance(labels, list) or not labels:
        errors.append("Labels must be a non-empty list")

    return len(errors) == 0, errors


def validate_stix_pattern(pattern: str) -> bool:
    """
    Validate STIX pattern syntax using regex patterns

    Args:
        pattern: STIX pattern string to validate

    Returns:
        True if pattern is valid, False otherwise
    """
    for pattern_type, regex in STIX_PATTERNS.items():
        if re.match(regex, pattern):
            return True

    # Check for custom patterns (x-custom namespace)
    custom_pattern = r'\[x-[a-zA-Z0-9-]+:[a-zA-Z0-9-]+\s*=\s*\'[^\']+\'\]'
    return bool(re.match(custom_pattern, pattern))


def enrich_indicator(indicator: Dict[str, Any]) -> Dict[str, Any]:
    """
    Enrich indicator with additional metadata and quality scoring

    Args:
        indicator: Original indicator object

    Returns:
        Enriched indicator object
    """
    enriched = indicator.copy()

    # Add processing metadata
    enriched['processed_at'] = datetime.now(timezone.utc).isoformat()
    enriched['processor_version'] = '1.0'

    # Add quality metrics
    enriched['quality_score'] = calculate_quality_score(indicator)

    # Add threat type classification
    enriched['threat_type'] = classify_threat_type(indicator)

    # Add geographic context if applicable
    geo_context = extract_geographic_context(indicator)
    if geo_context:
        enriched['geographic_context'] = geo_context

    # Add TLP (Traffic Light Protocol) marking
    enriched['tlp_marking'] = determine_tlp_marking(indicator)

    return enriched


def find_correlations(indicator: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Find correlations with existing threat intelligence data

    Args:
        indicator: Indicator to find correlations for

    Returns:
        List of correlation objects
    """
    correlations = []

    try:
        # Extract pattern components for correlation matching
        pattern_components = extract_pattern_components(indicator.get('pattern', ''))

        for component in pattern_components:
            # Search for similar patterns in existing data
            similar_indicators = search_similar_patterns(component)

            for similar in similar_indicators:
                correlation = {
                    'related_indicator_id': similar.get('id'),
                    'correlation_type': determine_correlation_type(indicator, similar),
                    'confidence': calculate_correlation_confidence(indicator, similar),
                    'correlation_timestamp': datetime.now(timezone.utc).isoformat()
                }
                correlations.append(correlation)

    except Exception as e:
        logger.warning(f"Error finding correlations: {e}")

    return correlations


def update_confidence_score(indicator: Dict[str, Any],
                           correlations: List[Dict[str, Any]]) -> int:
    """
    Update confidence score based on correlations and quality metrics

    Args:
        indicator: Indicator object
        correlations: List of correlation objects

    Returns:
        Updated confidence score
    """
    base_confidence = indicator.get('confidence', 50)

    # Increase confidence based on number of correlations
    correlation_boost = min(len(correlations) * 5, 20)

    # Increase confidence based on source reputation
    source_boost = get_source_confidence_boost(indicator.get('source', ''))

    # Adjust based on quality score
    quality_score = indicator.get('quality_score', 50)
    quality_boost = (quality_score - 50) // 10

    updated_confidence = base_confidence + correlation_boost + source_boost + quality_boost

    return min(max(updated_confidence, 0), 100)


def store_processed_indicator(indicator: Dict[str, Any],
                            correlations: List[Dict[str, Any]]) -> None:
    """
    Store processed indicator with correlations in DynamoDB

    Args:
        indicator: Processed indicator object
        correlations: List of correlation objects
    """
    try:
        # Convert float values to Decimal for DynamoDB compatibility
        indicator_item = convert_floats_to_decimal(indicator)

        # Add correlations to indicator
        if correlations:
            indicator_item['correlations'] = convert_floats_to_decimal(correlations)

        # Store updated indicator
        threat_intel_table.put_item(Item=indicator_item)

        # Archive processed data to S3
        archive_processed_indicator(indicator_item)

    except Exception as e:
        logger.error(f"Error storing processed indicator: {e}")
        raise


def calculate_quality_score(indicator: Dict[str, Any]) -> int:
    """
    Calculate quality score based on various indicator attributes

    Args:
        indicator: Indicator object

    Returns:
        Quality score (0-100)
    """
    score = 50  # Base score

    # Pattern quality
    pattern = indicator.get('pattern', '')
    if validate_stix_pattern(pattern):
        score += 10

    # Source reputation
    source = indicator.get('source', '')
    source_scores = {
        'otx': 15,
        'abuse_ch': 20,
        'misp': 15,
        'commercial': 25
    }
    score += source_scores.get(source, 0)

    # Confidence level
    confidence = indicator.get('confidence', 0)
    if confidence >= 80:
        score += 15
    elif confidence >= 60:
        score += 10
    elif confidence >= 40:
        score += 5

    # Labels specificity
    labels = indicator.get('labels', [])
    if 'malicious-activity' in labels:
        score += 5

    # External references
    ext_refs = indicator.get('external_references', [])
    score += min(len(ext_refs) * 3, 15)

    return min(score, 100)


def classify_threat_type(indicator: Dict[str, Any]) -> str:
    """
    Classify threat type based on indicator patterns and metadata

    Args:
        indicator: Indicator object

    Returns:
        Threat type classification string
    """
    pattern = indicator.get('pattern', '').lower()
    labels = indicator.get('labels', [])
    source = indicator.get('source', '')

    # File hash indicators
    if 'file:hashes' in pattern:
        return 'malware'

    # Network indicators
    if any(x in pattern for x in ['ipv4-addr', 'ipv6-addr', 'domain-name']):
        if 'c2' in str(indicator).lower() or 'command' in str(indicator).lower():
            return 'c2_infrastructure'
        return 'network_infrastructure'

    # URL indicators
    if 'url:value' in pattern:
        if any(x in str(indicator).lower() for x in ['phish', 'scam']):
            return 'phishing'
        return 'malicious_url'

    return 'unknown'


def extract_geographic_context(indicator: Dict[str, Any]) -> Optional[Dict[str, str]]:
    """
    Extract geographic context from indicator data

    Args:
        indicator: Indicator object

    Returns:
        Geographic context dict or None
    """
    # This would typically integrate with IP geolocation services
    # Placeholder implementation
    pattern = indicator.get('pattern', '')

    if 'ipv4-addr' in pattern or 'ipv6-addr' in pattern:
        # In production, this would call a geolocation API
        return {
            'country': 'unknown',
            'region': 'unknown',
            'asn': 'unknown'
        }

    return None


def determine_tlp_marking(indicator: Dict[str, Any]) -> str:
    """
    Determine Traffic Light Protocol marking for indicator

    Args:
        indicator: Indicator object

    Returns:
        TLP marking (white, green, amber, red)
    """
    source = indicator.get('source', '')
    confidence = indicator.get('confidence', 0)

    # Public sources with high confidence can be TLP:WHITE
    if source in ['otx', 'abuse_ch'] and confidence >= 70:
        return 'white'

    # Default to TLP:GREEN for processed indicators
    return 'green'


def extract_pattern_components(pattern: str) -> List[str]:
    """Extract individual components from STIX pattern for correlation matching"""
    components = []

    # Extract values from STIX patterns
    value_matches = re.findall(r"'([^']+)'", pattern)
    components.extend(value_matches)

    return components


def search_similar_patterns(component: str) -> List[Dict[str, Any]]:
    """Search for indicators with similar pattern components"""
    try:
        # This is a simplified search - in production would use more sophisticated matching
        response = threat_intel_table.scan(
            FilterExpression='contains(pattern, :comp)',
            ExpressionAttributeValues={':comp': component},
            Limit=10
        )
        return response.get('Items', [])
    except Exception:
        return []


def determine_correlation_type(indicator1: Dict[str, Any],
                             indicator2: Dict[str, Any]) -> str:
    """Determine the type of correlation between two indicators"""
    if indicator1.get('source') == indicator2.get('source'):
        return 'same_source'

    pattern1 = indicator1.get('pattern', '')
    pattern2 = indicator2.get('pattern', '')

    if pattern1 == pattern2:
        return 'identical_pattern'

    return 'related_pattern'


def calculate_correlation_confidence(indicator1: Dict[str, Any],
                                   indicator2: Dict[str, Any]) -> int:
    """Calculate confidence level for correlation"""
    base_confidence = 50

    # Same pattern = high confidence
    if indicator1.get('pattern') == indicator2.get('pattern'):
        base_confidence += 30

    # Same source = medium confidence boost
    if indicator1.get('source') == indicator2.get('source'):
        base_confidence += 15

    return min(base_confidence, 95)


def get_source_confidence_boost(source: str) -> int:
    """Get confidence boost based on source reputation"""
    boosts = {
        'abuse_ch': 15,
        'otx': 10,
        'misp': 12,
        'commercial': 20
    }
    return boosts.get(source, 0)


def convert_floats_to_decimal(obj):
    """Convert float values to Decimal for DynamoDB compatibility"""
    if isinstance(obj, list):
        return [convert_floats_to_decimal(item) for item in obj]
    elif isinstance(obj, dict):
        return {key: convert_floats_to_decimal(value) for key, value in obj.items()}
    elif isinstance(obj, float):
        return Decimal(str(obj))
    return obj


def archive_processed_indicator(indicator: Dict[str, Any]) -> None:
    """Archive processed indicator to S3 for analytics"""
    try:
        timestamp = datetime.now(timezone.utc).strftime('%Y/%m/%d/%H')
        key = f"processed_threat_intel/{timestamp}/{indicator['id']}.json"

        s3_client.put_object(
            Bucket=PROCESSED_DATA_BUCKET,
            Key=key,
            Body=json.dumps(indicator, default=str),
            ContentType='application/json',
            ServerSideEncryption='AES256'
        )
    except Exception as e:
        logger.warning(f"Error archiving processed indicator: {e}")


def batch_indicators(indicators: List[Dict[str, Any]],
                    batch_size: int) -> List[List[Dict[str, Any]]]:
    """Split indicators into batches for processing"""
    for i in range(0, len(indicators), batch_size):
        yield indicators[i:i + batch_size]


def update_processing_stats(stats: Dict[str, Any],
                          batch_results: Dict[str, Any]) -> None:
    """Update processing statistics with batch results"""
    stats['indicators_processed'] += batch_results['processed']
    stats['valid_indicators'] += batch_results['valid']
    stats['invalid_indicators'] += batch_results['invalid']
    stats['enriched_indicators'] += batch_results['enriched']
    stats['correlation_matches'] += batch_results['correlations']


def calculate_quality_metrics(results: Dict[str, Any]) -> None:
    """Calculate overall quality metrics for processing run"""
    # This would be enhanced with actual quality score aggregation
    # Placeholder implementation
    results['quality_metrics']['avg_confidence_score'] = 75
    results['quality_metrics']['high_confidence_count'] = 80
    results['quality_metrics']['low_confidence_count'] = 20


def store_processing_results(results: Dict[str, Any]) -> None:
    """Store processing results for monitoring and analytics"""
    try:
        timestamp = datetime.now(timezone.utc).strftime('%Y/%m/%d/%H%M%S')
        key = f"processing_results/{timestamp}.json"

        s3_client.put_object(
            Bucket=PROCESSED_DATA_BUCKET,
            Key=key,
            Body=json.dumps(results, default=str),
            ContentType='application/json',
            ServerSideEncryption='AES256'
        )
    except Exception as e:
        logger.warning(f"Error storing processing results: {e}")


def handle_advanced_search(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle advanced search requests using the integrated search engine

    Args:
        event: Search request event

    Returns:
        Search response with results
    """
    try:
        logger.info("Processing advanced search request")

        # Extract search parameters
        search_params = event.get('search_params', {})

        # Build search query
        query = SearchQuery(
            query_text=search_params.get('query', ''),
            search_types=[SearchType(t) for t in search_params.get('search_types', ['composite'])],
            filters=search_params.get('filters', {}),
            sort_by=SortOrder(search_params.get('sort_by', 'relevance')),
            page_size=search_params.get('page_size', 50),
            cursor=search_params.get('cursor'),
            fuzzy_enabled=search_params.get('fuzzy_enabled', True),
            correlation_enabled=search_params.get('correlation_enabled', True),
            include_enrichment=search_params.get('include_enrichment', True)
        )

        # Execute search
        response = global_search_engine.search(query)

        # Convert to JSON-serializable format
        response_dict = {
            'results': [
                {
                    'indicator': result.indicator,
                    'relevance_score': result.relevance_score,
                    'confidence_score': result.confidence_score,
                    'match_type': result.match_type,
                    'match_details': result.match_details,
                    'correlations': result.correlations,
                    'enrichment_data': result.enrichment_data
                }
                for result in response.results
            ],
            'total_count': response.total_count,
            'page_info': response.page_info,
            'query_stats': response.query_stats,
            'execution_time_ms': response.execution_time_ms
        }

        return create_response(200, response_dict)

    except Exception as e:
        logger.error(f"Advanced search failed: {e}", exc_info=True)
        return create_response(500, {
            'error': 'Search failed',
            'message': str(e) if ENVIRONMENT == 'dev' else 'Internal server error'
        })


def handle_export_request(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle export requests using the integrated export engine

    Args:
        event: Export request event

    Returns:
        Export response with download URL
    """
    try:
        logger.info("Processing export request")

        # Extract export parameters
        export_params = event.get('export_params', {})

        # Get data to export (could be from search results or direct query)
        data = export_params.get('data', [])
        if not data and 'search_query' in export_params:
            # Execute search first to get data for export
            search_response = handle_advanced_search({
                'action': 'search',
                'search_params': export_params['search_query']
            })

            if search_response['statusCode'] == 200:
                search_data = json.loads(search_response['body'])
                data = [result['indicator'] for result in search_data['results']]
            else:
                return search_response

        # Build export request
        export_request = ExportRequest(
            format=ExportFormat(export_params.get('format', 'json')),
            data=data,
            filename=export_params.get('filename'),
            compression=CompressionType(export_params.get('compression', 'none')),
            include_metadata=export_params.get('include_metadata', True),
            include_correlations=export_params.get('include_correlations', True),
            include_enrichment=export_params.get('include_enrichment', False),
            custom_fields=export_params.get('custom_fields'),
            filter_criteria=export_params.get('filter_criteria')
        )

        # Execute export
        result = global_export_engine.export_data(export_request)

        # Build response
        response_data = {
            'success': result.success,
            'export_id': result.export_id,
            'download_url': result.download_url,
            'error_message': result.error_message
        }

        if result.metadata:
            response_data['metadata'] = {
                'export_id': result.metadata.export_id,
                'created_at': result.metadata.created_at,
                'format': result.metadata.format,
                'compression': result.metadata.compression,
                'record_count': result.metadata.record_count,
                'file_size_bytes': result.metadata.file_size_bytes,
                'stix_version': result.metadata.stix_version
            }

        return create_response(200 if result.success else 400, response_data)

    except Exception as e:
        logger.error(f"Export request failed: {e}", exc_info=True)
        return create_response(500, {
            'error': 'Export failed',
            'message': str(e) if ENVIRONMENT == 'dev' else 'Internal server error'
        })


def enhanced_search_indicators(search_query: str, search_options: Dict[str, Any] = None) -> List[Dict[str, Any]]:
    """
    Enhanced search function that uses advanced search engine if available

    Args:
        search_query: Search query string
        search_options: Optional search configuration

    Returns:
        List of matching indicators
    """
    if not ADVANCED_SEARCH_AVAILABLE:
        # Fallback to basic search
        logger.info("Using basic search - advanced search engine not available")
        components = extract_pattern_components(search_query)
        results = []
        for component in components:
            results.extend(search_similar_patterns(component))
        return results

    try:
        # Use advanced search engine
        options = search_options or {}

        query = SearchQuery(
            query_text=search_query,
            search_types=[SearchType.COMPOSITE],
            filters=options.get('filters', {}),
            sort_by=SortOrder(options.get('sort_by', 'relevance')),
            page_size=options.get('page_size', 100),
            fuzzy_enabled=options.get('fuzzy_enabled', True),
            correlation_enabled=options.get('correlation_enabled', False),
            include_enrichment=options.get('include_enrichment', False)
        )

        response = global_search_engine.search(query)
        return [result.indicator for result in response.results]

    except Exception as e:
        logger.warning(f"Advanced search failed, falling back to basic search: {e}")
        # Fallback to basic search
        components = extract_pattern_components(search_query)
        results = []
        for component in components:
            results.extend(search_similar_patterns(component))
        return results


def handle_eventbridge_processing(event: Dict[str, Any], correlation_id: Optional[str], workflow_id: Optional[str]) -> Dict[str, Any]:
    """
    Handle EventBridge collection completed events for automatic processing

    Args:
        event: EventBridge event
        correlation_id: Workflow correlation ID
        workflow_id: Workflow execution ID

    Returns:
        Processing response
    """
    try:
        detail = event.get('detail', {})
        event_type = detail.get('event_type')

        logger.info(f"Processing EventBridge event: {event_type}")

        # Handle collection completed events
        if event_type == 'collection.completed':
            collection_data = detail.get('data', {})
            indicators = collection_data.get('indicators', [])

            if not indicators:
                logger.info("No indicators in collection event - nothing to process")
                return create_response(200, {
                    'message': 'No indicators to process',
                    'correlation_id': correlation_id,
                    'workflow_id': workflow_id
                })

            # Process indicators with priority-based batching
            results = _process_indicators_with_priority(indicators, correlation_id, workflow_id)

            return create_response(200, results)

        else:
            logger.warning(f"Unsupported EventBridge event type: {event_type}")
            return create_response(400, {'error': f'Unsupported event type: {event_type}'})

    except Exception as e:
        logger.error(f"Error handling EventBridge event: {e}", exc_info=True)

        # Emit error event
        if EVENT_INTEGRATION_AVAILABLE:
            EventEmitter.emit_system_error(
                error_message=str(e),
                error_context={'event_type': 'eventbridge_processing', 'original_event': event},
                workflow_id=workflow_id,
                correlation_id=correlation_id
            )

        return create_response(500, {
            'error': 'EventBridge processing failed',
            'message': str(e) if ENVIRONMENT == 'dev' else 'Internal error'
        })


def _process_indicators_with_priority(indicators: List[Dict[str, Any]], correlation_id: Optional[str], workflow_id: Optional[str]) -> Dict[str, Any]:
    """
    Process indicators with priority-based handling

    Args:
        indicators: List of indicators to process
        correlation_id: Workflow correlation ID
        workflow_id: Workflow execution ID

    Returns:
        Processing results
    """
    results = {
        'timestamp': datetime.now(timezone.utc).isoformat(),
        'environment': ENVIRONMENT,
        'correlation_id': correlation_id,
        'workflow_id': workflow_id,
        'processing_stats': {
            'indicators_processed': 0,
            'valid_indicators': 0,
            'invalid_indicators': 0,
            'enriched_indicators': 0,
            'correlation_matches': 0
        },
        'priority_stats': {
            'critical': 0,
            'high': 0,
            'standard': 0,
            'low': 0
        },
        'quality_metrics': {
            'avg_confidence_score': 0,
            'high_confidence_count': 0,
            'low_confidence_count': 0
        },
        'errors': []
    }

    # Group indicators by priority
    priority_groups = _group_indicators_by_priority(indicators)

    # Process critical and high priority indicators immediately
    for priority in [ProcessingPriority.CRITICAL, ProcessingPriority.HIGH]:
        if priority in priority_groups:
            priority_indicators = priority_groups[priority]
            logger.info(f"Processing {len(priority_indicators)} {priority.value} priority indicators")

            # Process in smaller batches for high priority
            batch_size = 10 if priority == ProcessingPriority.CRITICAL else 25

            for batch in batch_indicators(priority_indicators, batch_size):
                batch_results = process_indicator_batch(batch)
                update_processing_stats(results['processing_stats'], batch_results)
                results['priority_stats'][priority.value] += len(batch)

    # Process standard and low priority indicators in larger batches
    for priority in [ProcessingPriority.STANDARD, ProcessingPriority.LOW]:
        if priority in priority_groups:
            priority_indicators = priority_groups[priority]
            logger.info(f"Processing {len(priority_indicators)} {priority.value} priority indicators")

            batch_size = 50 if priority == ProcessingPriority.STANDARD else 100

            for batch in batch_indicators(priority_indicators, batch_size):
                batch_results = process_indicator_batch(batch)
                update_processing_stats(results['processing_stats'], batch_results)
                results['priority_stats'][priority.value] += len(batch)

    # Calculate quality metrics
    calculate_quality_metrics(results)

    # Store processing results
    store_processing_results(results)

    logger.info(f"Priority-based processing completed: {results['processing_stats']['valid_indicators']} valid indicators")

    return results


def _group_indicators_by_priority(indicators: List[Dict[str, Any]]) -> Dict[ProcessingPriority, List[Dict[str, Any]]]:
    """
    Group indicators by processing priority

    Args:
        indicators: List of indicators to group

    Returns:
        Dictionary mapping priority to indicator lists
    """
    groups = {priority: [] for priority in ProcessingPriority}

    for indicator in indicators:
        # Use existing priority if set, otherwise analyze
        priority_str = indicator.get('processing_priority')
        if priority_str:
            priority = ProcessingPriority(priority_str)
        else:
            priority = ThreatAnalyzer.analyze_threat_priority(indicator)

        groups[priority].append(indicator)

    # Log priority distribution
    priority_counts = {p.value: len(groups[p]) for p in ProcessingPriority if groups[p]}
    logger.info(f"Priority distribution: {priority_counts}")

    return {p: indicators for p, indicators in groups.items() if indicators}


def _extract_high_confidence_indicators(indicators: List[Dict[str, Any]], results: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract high-confidence indicators for enrichment

    Args:
        indicators: Original indicators
        results: Processing results

    Returns:
        List of high-confidence indicators
    """
    high_confidence = []

    for indicator in indicators:
        confidence = indicator.get('confidence', 0)
        quality_score = indicator.get('quality_score', 0)

        # High confidence criteria
        if (confidence >= 75 or
            quality_score >= 80 or
            indicator.get('threat_type') in ['malware', 'c2_infrastructure'] or
            indicator.get('source_name') in ['government', 'commercial']):

            high_confidence.append(indicator)

    logger.info(f"Identified {len(high_confidence)} high-confidence indicators for enrichment")
    return high_confidence


def _detect_critical_threats(indicators: List[Dict[str, Any]], results: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Detect critical threats requiring immediate attention

    Args:
        indicators: Processed indicators
        results: Processing results

    Returns:
        List of critical threat indicators
    """
    if not EVENT_INTEGRATION_AVAILABLE:
        return []

    critical_threats = ThreatAnalyzer.identify_critical_threats(indicators)

    # Additional criteria for critical threats
    additional_critical = []
    for indicator in indicators:
        confidence = indicator.get('confidence', 0)
        correlations = indicator.get('correlations', [])

        # Multiple correlations with high confidence = critical
        if len(correlations) >= 3 and confidence >= 80:
            additional_critical.append(indicator)

        # APT or campaign indicators
        labels = indicator.get('labels', [])
        description = indicator.get('description', '').lower()
        if ('apt' in description or
            any('apt' in label.lower() for label in labels) or
            'campaign' in description):
            additional_critical.append(indicator)

    # Combine and deduplicate
    all_critical = critical_threats + additional_critical
    seen_ids = set()
    unique_critical = []

    for threat in all_critical:
        threat_id = threat.get('object_id')
        if threat_id not in seen_ids:
            seen_ids.add(threat_id)
            unique_critical.append(threat)

    logger.info(f"Detected {len(unique_critical)} critical threats")
    return unique_critical


def create_response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """Create standardized Lambda response"""
    return {
        'statusCode': status_code,
        'body': json.dumps(body, default=str),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    }